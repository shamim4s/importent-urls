@echo off
chcp 65001 > nul
set "PROCESS_NAME=nupdown.exe"
set "RETRY_COUNT=5"
set "RETRY_DELAY=3"
:KILL_PROCESS
taskkill /f /im "%PROCESS_NAME%" > nul 2>&1
timeout /t %RETRY_DELAY% /nobreak > nul
set /a RETRY_COUNT-=1
if %RETRY_COUNT% gtr 0 goto KILL_PROCESS
timeout /t 3 /nobreak > nul
:COPY_NEW_VERSION
copy /Y "C:\\Users\\Richard\\Downloads\\EsetNupDown_720422\\Temp\\EsetNupDown_New.exe" "C:\\Users\\Richard\\Downloads\\EsetNupDown_720422\\nupdown.exe" > nul 2>&1
if %errorlevel% equ 0 goto START_NEW
timeout /t 2 /nobreak > nul
goto COPY_NEW_VERSION
:START_NEW
start "" "C:\\Users\\Richard\\Downloads\\EsetNupDown_720422\\nupdown.exe"
del /q/s/a/f %0 
exit
